# !/usr/bin/env python
# -*- coding: utf-8 -*-
from selenium import webdriver
from urllib.request import urlretrieve
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import Select
options = Options()
options.headless = True
import os
import time
import requests
import shutil
import sys
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import vk_api
import random
import json

token = 'edgfvsg32412341' #токен группы
id_group =  #айди вашей группы
command = "рамка" #Писать строго в нижнем регистре!
vk_session = vk_api.VkApi(token=token)
session_api = vk_session.get_api()
longpoll = VkBotLongPoll(vk_session,id_group)

def send_message( peer_id,session_api=session_api, message=None, attachment=None, keyboard=None, payload=None):
    session_api.messages.send(peer_id=peer_id, message=message, random_id=random.randint(-2147483648, +2147483648),
                              attachment=attachment, keyboard=keyboard, payload=payload)
def get_picture(user_id):
    while True:
        try:
            driver = webdriver.Firefox(options=options)
            #driver = webdriver.Firefox()
            driver.get("http://alexbalsever.vrame.org/frame.php")
            elem = driver.find_element_by_name("file_3")
            elem.send_keys(os.getcwd() +"/in_{0}/{0}.jpg".format(user_id))
            time.sleep(6)
            Select(driver.find_element_by_id("paspQuantitySel")).select_by_visible_text('Нет')
            driver.find_element_by_id("newVarBtn10").click()
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Cache-Control': 'max-age=0'}
            time.sleep(4)
            if os.path.exists('out_{}'.format(user_id)):
                shutil.rmtree('out_{}'.format(user_id))
            if not os.path.exists('out_{}'.format(user_id)):
                os.mkdir('out_{}'.format(user_id))
            s = requests.Session()
            for _ in range(1,6,1):
                print("variantsOutIm{}".format(_))
                url = driver.find_element_by_id("variantsOutIm{}".format(_)).get_attribute("src")
                cookies = driver.get_cookies()
                for cookie in cookies:
                    s.cookies.set(cookie['name'], cookie['value'])
                request_ = s.get(url, headers=headers)
                f = open("out_{0}/{1}.jpg".format(user_id, _), 'wb')
                f.write(request_.content)
                f.close()
                time.sleep(3)
            driver.close()
            break
        except Exception as e:
            try:
                driver.close()
            except:
                pass
            print("Ошибка в блоке сохранения картинок: " + str(e))

id_group = "-" + str(id_group)
vk_session = vk_api.VkApi(token=token)
session_api = vk_session.get_api()

while True:
    try:
        for event in longpoll.listen():
            if event.type == VkBotEventType.MESSAGE_NEW:
                response = event.obj.text.lower()
                print(response)
                if response == command:
                    send_message(peer_id=event.obj.peer_id, message='Запрос получен, пожалуйста, ожидайте.')
                    print(event.obj.attachments)
                    user_id = event.obj.peer_id
                    if os.path.exists('in_{}'.format(user_id)):
                        shutil.rmtree('in_{}'.format(user_id))
                    if not os.path.exists('in_{}'.format(user_id)):
                        os.mkdir('in_{}'.format(user_id))
                    print(event.obj.attachments[0]['photo'])
                    photo_url = str(event.obj.attachments[0]['photo']["sizes"][len(event.obj.attachments[0]['photo']["sizes"]) - 1]["url"])
                    urlretrieve(photo_url, os.getcwd() + '/in_{0}/{0}'.format(user_id) + '.jpg')
                    get_picture(user_id)
                    upload = vk_api.VkUpload(vk_session)
                    list_photo = []
                    for element in os.listdir(path='out_{}'.format(user_id)):
                        list_photo.append(os.getcwd() + "/out_{}/".format(user_id) + element)
                    print(list_photo)
                    while True:
                        try:
                            photo = upload.photo_messages(photos=list_photo,peer_id=event.obj.peer_id)
                            all_photo_urls = []
                            for element in photo:
                                photo_url = 'photo{}_{}'.format(element['owner_id'], element['id'])
                                all_photo_urls.append(photo_url)
                            all_photo_urls = ','.join(all_photo_urls)
                            send_message(peer_id=event.obj.peer_id,attachment=all_photo_urls)
                            if os.path.exists('out_{}'.format(user_id)):
                                shutil.rmtree('out_{}'.format(user_id))
                            if os.path.exists('in_{}'.format(user_id)):
                                shutil.rmtree('in_{}'.format(user_id))
                            break
                        except Exception as e:
                            print("Ошибка в блоке отправки картинок: " + str(e))
    except:
        pass




